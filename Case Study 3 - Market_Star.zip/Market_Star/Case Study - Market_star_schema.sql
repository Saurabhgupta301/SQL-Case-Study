-- Rank demo

USE market_star_schema;

-- Ranks of various record

SELECT customer_name, 
	   ord_id,
       ROUND(sales) AS rounded_sales,
       RANK() OVER(ORDER BY sales DESC) AS sales_rank
FROM market_fact_full AS m 
INNER JOIN cust_dimen AS c
ON m.cust_id = c.cust_id
WHERE customer_name = 'RICK WILSON';

-- Top 10 sales orders from RICK WILSON  

with rank_info as 
(
SELECT customer_name, 
	   ord_id,
       ROUND(sales) AS rounded_sales,
       RANK() OVER(ORDER BY sales DESC) AS sales_rank
FROM market_fact_full AS m 
INNER JOIN cust_dimen AS c
ON m.cust_id = c.cust_id
WHERE customer_name = 'RICK WILSON'
)
select * 
from rank_info 
where sales_rank<=10;

-- Example for Dense Rank
select ord_id,
       discount,
       customer_name,
       Rank() over(order by discount desc) as disc_rank,
       Dense_rank() over(order by discount desc) as disc_dense_rank
from market_fact_full as m
inner join cust_dimen as c 
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON';

-- No. of order each customer has placed

Select customer_name,
	   count(distinct ord_id) as order_count,
       Rank() over (order by count(distinct ord_id) desc) as order_rank,
       Dense_rank() over (order by count(distinct ord_id) desc) as order_dense_rank,
       Row_number() over (order by count(distinct ord_id) desc) as order_row_number
from market_fact_full as m
inner join cust_dimen as c
on m.cust_id = c.cust_id
group by customer_name;

-- Partition Example

select ship_mode ,
       month(ship_date) as shipping_month,
	   count(*) as shipments
from shipping_dimen
group by ship_mode,
         month(ship_date);
         
with shipping_summary as
(
select ship_mode ,
       month(ship_date) as shipping_month,
	   count(*) as shipments
from shipping_dimen
group by ship_mode,
         month(ship_date)
)
 select *,
 rank() over(partition by ship_mode order by shipments desc) as shipping_rank,
 dense_rank() over(partition by ship_mode order by shipments desc) as shipping_dense_rank,
 row_number() over(partition by ship_mode order by shipments desc) as shipping_row_number
 from shipping_summary;
 
 -- Example of Named Window function
 
 select ord_id,
       discount,
       customer_name,
       Rank() over w as disc_rank,
       Dense_rank() over w as disc_dense_rank,
       Row_number() over w as disc_row_num
from market_fact_full as m
inner join cust_dimen as c 
on m.cust_id = c.cust_id
window w as (order by discount desc);

 select ord_id,
       discount,
       customer_name,
       Rank() over w as disc_rank,
       Dense_rank() over w as disc_dense_rank,
       Row_number() over w as disc_row_num
from market_fact_full as m
inner join cust_dimen as c 
on m.cust_id = c.cust_id
window w as (partition by customer_name order by discount desc);

-- Frames Example
with daily_shipping_summary as
( 
select ship_date,
       sum(shipping_cost) as daily_total
from market_fact_full as m
inner join 
shipping_dimen as s
on m.ship_id = s.ship_id
group by ship_date
)
select * ,
          sum(daily_total) over w1 as running_total,
          avg(daily_total) over w2 as moving_avg
from daily_shipping_summary
window w1 as (order by ship_date rows unbounded preceding),
w2 as (order by ship_date rows 6 preceding);

-- Example of Lead Function
-- (a) getting all the order details by RICK WILSON
select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date;

 -- (b) putting the entire thing in a common table expression
 with cust_order as
 (
 select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date
)
select *,
		lead(order_date,1) over (order by order_date, ord_id) as next_order_date
from cust_order
order by customer_name,
         order_date,
         ord_id;  
         
-- (c) to provide defaualt value inplace of null values use '2015-01-01' in the lead expression
select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date;

 -- (b) putting the entire thing in a common table expression
 with cust_order as
 (
 select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date
)
select *,
		lead(order_date,1, '2015-01-01') over (order by order_date, ord_id) as next_order_date
from cust_order
order by customer_name,
         order_date,
         ord_id; 

-- Lets compute the difference between two dates , for that lets make one more common table expression

select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date;

 -- (b) putting the entire thing in a common table expression
 with cust_order as
 (
 select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date
),
next_date_summary as 
(
select *,
		lead(order_date,1) over (order by order_date, ord_id) as next_order_date
from cust_order
order by customer_name,
         order_date,
         ord_id
)
select *,
datediff(next_order_date, order_date) as days_diff
from next_date_summary;

-- Lag example 
-- we can use same example for lag to compute previous date and difference also 
-- simply change the keyword lead by lag

 with cust_order as
 (
 select c.customer_name ,
       m.ord_id,
       o.order_date
from 
market_fact_full as m
left join 
orders_dimen as o
on m.ord_id = o.ord_id
left join
cust_dimen as c
on m.cust_id = c.cust_id
where customer_name = 'RICK WILSON'
group by c.customer_name, 
         m.ord_id,
         o.order_date
),
previous_date_summary as 
(
select *,
		lag(order_date,1,2015-01-01) over (order by order_date, ord_id) as previous_order_date
from cust_order
order by customer_name,
         order_date,
         ord_id
)
select *,
datediff(order_date, previous_order_date) as days_diff
from previous_date_summary;

-- Case Statement
-- case when example
/* profit < -500 -> huge loss
   profit -500 to 0 -> bearable loss
   profit 0 to 500 -> decent profit
   profit > 500 great profit
*/
select market_fact_id, 
	profit,
	case 
         when profit <-500 then 'Huge Loss'
         when profit between -500 and 0 then 'bearable loss'
         when profit between 0 and 500 then 'Decent Profit'
	     else 'Great Profit'
    end as Profit_type 
from market_fact_full;

-- Classify customers on the following criteria
-- Top 10 % of customers as Gold
-- Next 40 % of customers as Silver
-- Rest 50 % of customers as Bronze

select m.cust_id,
       c.customer_name,
       round(sum(m.sales)) as total_sales,
       percent_rank() over (order by round(sum(m.sales)) desc) as perc_rank
from market_fact_full as m
left join cust_dimen as c
on m.cust_id = c.cust_id
group by cust_id;

-- lets use common table expression (sub query)
with cust_summary as
(
 select m.cust_id,
       c.customer_name,
       round(sum(m.sales)) as total_sales,
       percent_rank() over (order by round(sum(m.sales)) desc) as perc_rank
from market_fact_full as m
left join cust_dimen as c
on m.cust_id = c.cust_id
group by cust_id
)
select *,
        case
            when perc_rank < 0.1 then 'Gold'
            when perc_rank < 0.5 then 'Silver'
            else 'Bronze'
		end as customer_category
from cust_summary;

-- UDFs
DELIMITER $$

CREATE FUNCTION profitType(profit int)
RETURNS VARCHAR(30) DETERMINISTIC

BEGIN

DECLARE message VARCHAR(30);
IF profit<-500 THEN
	SET message = 'Huge Loss';
ELSEIF profit BETWEEN -500 AND 0 THEN 
	SET message = 'Bearable Loss';
ELSEIF profit BETWEEN 0 AND 500 THEN
	SET message = 'Decent Profit';
ELSE
	SET message = 'Great Profit';
END IF;

RETURN message;

END;
$$
DELIMITER ;

SELECT profitType(-20) as Function_output;



-- Stored Procedures

DELIMITER $$

CREATE PROCEDURE get_sales_customers (sales_input INT)
BEGIN
	SELECT DISTINCT cust_id,
					ROUND(sales) AS sales_amount
	FROM
		market_fact_full
	WHERE ROUND(sales)>sales_input
    ORDER BY sales;
    
END $$

DELIMITER ;

CALL get_sales_customers(300);

DROP PROCEDURE get_sales_customers;


-- Query best practices 

-- Comment Section

/*
Comment Section with
multiple lines
*/

SELECT fact.ord_id, order_date
FROM market_fact_full AS fact INNER JOIN orders_dimen AS ord ON fact.ord_id = ord.ord_id
ORDER BY fact.ord_id , order_date;


SELECT fact.ord_id,
       order_date
FROM   market_fact_full AS fact
       INNER JOIN orders_dimen AS ord
               ON fact.ord_id = ord.ord_id
ORDER  BY fact.ord_id,
          order_date;  

-- Index Demo
CREATE TABLE market_fact_temp AS
SELECT * 
FROM
	market_fact_full;

CREATE INDEX filter_index ON market_fact_temp (cust_id, ship_id, prod_id);

ALTER TABLE market_fact_temp DROP INDEX filter_index;


-- Types of Indexes
SELECT * FROM market_fact_full;

-- Query Optimisation with understanding of Order of Query execution
-- Problem: Top 10 order ids and the customers who did them

SELECT ord_id,
		customer_name 
FROM
(
SELECT  m.*,c.customer_name,
        RANK() OVER (ORDER BY sales DESC) AS sales_rank,
        DENSE_RANK() OVER (ORDER BY sales DESC) AS sales_dense_rank,
        ROW_NUMBER() OVER (ORDER BY sales DESC) AS sales_row_num
FROM 
market_fact_full as m
LEFT JOIN
cust_dimen as c
ON m.cust_id = c.cust_id
ORDER BY sales desc
) as a
LIMIT 10;



SELECT ord_id,
		customer_name 
FROM
(
SELECT  ord_id,c.customer_name,
        ROW_NUMBER() OVER (ORDER BY sales DESC) AS sales_row_num
FROM 
market_fact_full as m
INNER JOIN
cust_dimen as c
ON m.cust_id = c.cust_id
) as a
WHERE sales_row_num<=10;


/* ------------------------------------------------------------------------------------------
Problem Statement : Growth team wants to understand sustainble(profitable) product categories.
Sustainability can be achieved when we make better profits or atleast positive profits.
  We can look at the profits per product category.
  We can look at profits per product subcategory.
  We can check average profit per order 
  Also, consider Average profit % per order
  ----------------------------------------------------------------------------------------------*/
  -- (1)  Profits per product category 
  SELECT 
        p.Product_Category,
	--  p.Product_Sub_Category,
        SUM(m.Profit) AS Profits
  FROM 
       market_fact_full AS m
  INNER JOIN 
       prod_dimen AS p 
  ON   m.prod_id = p.prod_id
  GROUP BY 
		p.Product_Category
    --  p.Product_Sub_Category
  ORDER BY 
		SUM(m.Profit);
        
-- (2)  Profits per product subcategory
  SELECT 
	    p.Product_Category,
	    p.Product_Sub_Category,
        SUM(m.Profit) AS Profits
  FROM 
       market_fact_full AS m
  INNER JOIN 
       prod_dimen AS p 
  ON   m.prod_id = p.prod_id
  GROUP BY 
      p.Product_Category,
      p.Product_Sub_Category
  ORDER BY 
        p.Product_Category,
		SUM(m.Profit);
        
-- (3) Average profit per order

SELECT 
	p.Product_Category,
    SUM(m.Profit) AS Profit,
    ROUND(
			SUM(m.Profit) / COUNT(DISTINCT o.order_number)
			,2) AS Avg_profit_per_order
FROM 
	market_fact_full AS m
INNER JOIN 
	prod_dimen AS p
    ON m.prod_id = p.prod_id
		INNER JOIN 
        orders_dimen AS o
        ON m.ord_id = o.ord_id
GROUP BY 
	p.Product_Category
ORDER BY 
	p.Product_Category,
    SUM(m.Profit);

-- (4) Average profit percentage per order

SELECT 
	p.Product_Category,
    SUM(m.Profit) AS Profit,
    COUNT(DISTINCT o.order_number) AS Total_number,
    ROUND(SUM(m.Profit) / COUNT(DISTINCT o.order_number),2) AS Avg_profit_per_order,
    ROUND(SUM(m.Sales) / COUNT(DISTINCT o.order_number),2) AS Avg_sales_per_order,
    ROUND(SUM(m.Profit) / SUM(m.Sales),4)*100 AS Profit_percentage 
FROM 
	market_fact_full AS m
INNER JOIN 
	prod_dimen AS p
    ON m.prod_id = p.prod_id
		INNER JOIN 
        orders_dimen AS o
        ON m.ord_id = o.ord_id
GROUP BY 
	p.Product_Category
ORDER BY 
	p.Product_Category,
    SUM(m.Profit);
    
    
   /*-----------------------------------------------------------------------------------------------
   Problem statement: Extract the details of the top ten customers in form of a table shown below :
   cust_id
   rank
   customer_name
   profit
   customer_city
   customer_state
   sales
   -------------------------------------------------------------------------------------------------
   */
   
   -- Exploring cust_dimen table
   
SELECT 
	cust_id,
	customer_name,
	city AS customer_city,
	state AS customer_state
FROM 
	cust_dimen
WHERE cust_id LIKE 'cust_1%';

-- Ranking

WITH cust_summary AS
(
   SELECT 
	c.cust_id,
    RANK() OVER(ORDER BY SUM(profit) DESC) AS customer_rank,
	customer_name,
    ROUND(SUM(profit),2) AS profit,
	city AS customer_city,
	state AS customer_state,
    ROUND(SUM(sales),2) as sales
FROM 
	cust_dimen AS c
    INNER JOIN 
		market_fact_full AS m
        ON c.cust_id = m.cust_id
GROUP BY cust_id
)
SELECT * 
FROM cust_summary
-- TO SELECT TOP 10 customers. 
WHERE customer_rank <= 10;

/*--------------------------------------------------------------------------------------------
Problem statement: Extract the required details of the customers who have not placed an order yet.
Expected columns: The columns that are required as the output are as follows:

'cust_id'
'cust_name'
'city'
'state'
'customer_segment'
A flag to indicate that there is another customer with the exact same name and city 
but a different customer ID.(to understand if the same customer signed up again) 
------------------------------------------------------------------------------------------------------------------*/

-- Exploring customer_dimen table

SELECT * 
FROM cust_dimen;

-- List all customers who have not placed any order
SELECT c.*
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
WHERE m.ord_id IS NULL;

-- ANS= There is no such customer

-- Checking if really no such customers exist
SELECT COUNT(cust_id) FROM cust_dimen;
-- 1832
SELECT COUNT(DISTINCT cust_id) FROM market_fact_full;
-- 1832

-- That means our query is Right .

/*--------------------------------------------------------------------------------------------
Problem statement: Extract the required details of the customers who have placed only one order and more than one order so far.
Expected columns: The columns that are required as the output are as follows:

'cust_id'
'cust_name'
'city'
'state'
'customer_segment'
A flag to indicate that there is another customer with the exact same name and city 
but a different customer ID.(to understand if the same customer signed up again)*/

-- Exploring orders per user.

-- Customers who have placed only one order
SELECT c.*,
	COUNT(DISTINCT ord_id) AS order_count
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
GROUP BY cust_id
HAVING COUNT(DISTINCT ord_id)=1;

-- Customers who have placed more than one order
SELECT c.*,
	COUNT(DISTINCT ord_id) AS order_count
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
GROUP BY cust_id
HAVING COUNT(DISTINCT ord_id)<>1;

-- FRAUD DETECTION

-- (A) Check Unique customer name and city

SELECT
    customer_name,
	city,
	COUNT(cust_id) AS cust_id_count
FROM 
    cust_dimen 
GROUP BY 
    customer_name,
	city
Having COUNT(cust_id) > 1;  -- So we have the unique list of users who have exact same name and same city but they have two cust_id

-- FINAL OUTPUT

WITH cust_details
AS
(
	  SELECT c.*,
		COUNT(DISTINCT ord_id) AS order_count
	FROM 
		cust_dimen AS c
	LEFT JOIN 
		market_fact_full AS m
		ON c.cust_id = m.cust_id
	GROUP BY cust_id
	HAVING COUNT(DISTINCT ord_id)<>1
),
fraud_cust_list As 
(
 SELECT
    customer_name,
	city,
	COUNT(cust_id) AS cust_id_count
FROM 
    cust_dimen 
GROUP BY 
    customer_name,
	city
Having COUNT(cust_id) > 1
)
  SELECT
		cd.* ,
        CASE WHEN fc.cust_id_count IS NOT NULL 
			THEN 'FRAUD' 
		ELSE 'NORMAL' 
        END AS fraud_flag
		
  FROM 
	cust_details AS cd
    LEFT JOIN 
    fraud_cust_list as fc
		ON cd.customer_name = fc.customer_name AND
			cd.city = fc.city;