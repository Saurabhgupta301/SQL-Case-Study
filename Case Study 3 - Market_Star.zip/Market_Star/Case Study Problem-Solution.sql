USE market_star_schema;

/* ------------------------------------------------------------------------------------------
Problem Statement : Growth team wants to understand sustainble(profitable) product categories.
Sustainability can be achieved when we make better profits or atleast positive profits.
  We can look at the profits per product category.
  We can look at profits per product subcategory.
  We can check average profit per order 
  Also, consider Average profit % per order
  ----------------------------------------------------------------------------------------------*/
  -- (1)  Profits per product category 
  SELECT 
        p.Product_Category,
	--  p.Product_Sub_Category,
        SUM(m.Profit) AS Profits
  FROM 
       market_fact_full AS m
  INNER JOIN 
       prod_dimen AS p 
  ON   m.prod_id = p.prod_id
  GROUP BY 
		p.Product_Category
    --  p.Product_Sub_Category
  ORDER BY 
		SUM(m.Profit);
        
-- (2)  Profits per product subcategory
  SELECT 
	    p.Product_Category,
	    p.Product_Sub_Category,
        SUM(m.Profit) AS Profits
  FROM 
       market_fact_full AS m
  INNER JOIN 
       prod_dimen AS p 
  ON   m.prod_id = p.prod_id
  GROUP BY 
      p.Product_Category,
      p.Product_Sub_Category
  ORDER BY 
        p.Product_Category,
		SUM(m.Profit);
        
-- (3) Average profit per order

SELECT 
	p.Product_Category,
    SUM(m.Profit) AS Profit,
    ROUND(
			SUM(m.Profit) / COUNT(DISTINCT o.order_number)
			,2) AS Avg_profit_per_order
FROM 
	market_fact_full AS m
INNER JOIN 
	prod_dimen AS p
    ON m.prod_id = p.prod_id
		INNER JOIN 
        orders_dimen AS o
        ON m.ord_id = o.ord_id
GROUP BY 
	p.Product_Category
ORDER BY 
	p.Product_Category,
    SUM(m.Profit);

-- (4) Average profit percentage per order

SELECT 
	p.Product_Category,
    SUM(m.Profit) AS Profit,
    COUNT(DISTINCT o.order_number) AS Total_number,
    ROUND(SUM(m.Profit) / COUNT(DISTINCT o.order_number),2) AS Avg_profit_per_order,
    ROUND(SUM(m.Sales) / COUNT(DISTINCT o.order_number),2) AS Avg_sales_per_order,
    ROUND(SUM(m.Profit) / SUM(m.Sales),4)*100 AS Profit_percentage 
FROM 
	market_fact_full AS m
INNER JOIN 
	prod_dimen AS p
    ON m.prod_id = p.prod_id
		INNER JOIN 
        orders_dimen AS o
        ON m.ord_id = o.ord_id
GROUP BY 
	p.Product_Category
ORDER BY 
	p.Product_Category,
    SUM(m.Profit);
    
    
   /*-----------------------------------------------------------------------------------------------
   Problem statement: Extract the details of the top ten customers in form of a table shown below :
   cust_id
   rank
   customer_name
   profit
   customer_city
   customer_state
   sales
   -------------------------------------------------------------------------------------------------
   */
   
   -- Exploring cust_dimen table
   
SELECT 
	cust_id,
	customer_name,
	city AS customer_city,
	state AS customer_state
FROM 
	cust_dimen
WHERE cust_id LIKE 'cust_1%';

-- Ranking

WITH cust_summary AS
(
   SELECT 
	c.cust_id,
    RANK() OVER(ORDER BY SUM(profit) DESC) AS customer_rank,
	customer_name,
    ROUND(SUM(profit),2) AS profit,
	city AS customer_city,
	state AS customer_state,
    ROUND(SUM(sales),2) as sales
FROM 
	cust_dimen AS c
    INNER JOIN 
		market_fact_full AS m
        ON c.cust_id = m.cust_id
GROUP BY cust_id
)
SELECT * 
FROM cust_summary
-- TO SELECT TOP 10 customers. 
WHERE customer_rank <= 10;

/*--------------------------------------------------------------------------------------------
Problem statement: Extract the required details of the customers who have not placed an order yet.
Expected columns: The columns that are required as the output are as follows:

'cust_id'
'cust_name'
'city'
'state'
'customer_segment'
A flag to indicate that there is another customer with the exact same name and city 
but a different customer ID.(to understand if the same customer signed up again) 
------------------------------------------------------------------------------------------------------------------*/

-- Exploring customer_dimen table

SELECT * 
FROM cust_dimen;

-- List all customers who have not placed any order
SELECT c.*
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
WHERE m.ord_id IS NULL;

-- ANS= There is no such customer

-- Checking if really no such customers exist
SELECT COUNT(cust_id) FROM cust_dimen;
-- 1832
SELECT COUNT(DISTINCT cust_id) FROM market_fact_full;
-- 1832

-- That means our query is Right .

/*--------------------------------------------------------------------------------------------
Problem statement: Extract the required details of the customers who have placed only one order and more than one order so far.
Expected columns: The columns that are required as the output are as follows:

'cust_id'
'cust_name'
'city'
'state'
'customer_segment'
A flag to indicate that there is another customer with the exact same name and city 
but a different customer ID.(to understand if the same customer signed up again)*/

-- Exploring orders per user.

-- Customers who have placed only one order
SELECT c.*,
	COUNT(DISTINCT ord_id) AS order_count
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
GROUP BY cust_id
HAVING COUNT(DISTINCT ord_id)=1;

-- Customers who have placed more than one order
SELECT c.*,
	COUNT(DISTINCT ord_id) AS order_count
FROM 
	cust_dimen AS c
LEFT JOIN 
	market_fact_full AS m
    ON c.cust_id = m.cust_id
GROUP BY cust_id
HAVING COUNT(DISTINCT ord_id)<>1;

-- FRAUD DETECTION

-- (A) Check Unique customer name and city

SELECT
    customer_name,
	city,
	COUNT(cust_id) AS cust_id_count
FROM 
    cust_dimen 
GROUP BY 
    customer_name,
	city
Having COUNT(cust_id) > 1;  -- So we have the unique list of users who have exact same name and same city but they have two cust_id

-- FINAL OUTPUT

WITH cust_details
AS
(
	  SELECT c.*,
		COUNT(DISTINCT ord_id) AS order_count
	FROM 
		cust_dimen AS c
	LEFT JOIN 
		market_fact_full AS m
		ON c.cust_id = m.cust_id
	GROUP BY cust_id
	HAVING COUNT(DISTINCT ord_id)<>1
),
fraud_cust_list As 
(
 SELECT
    customer_name,
	city,
	COUNT(cust_id) AS cust_id_count
FROM 
    cust_dimen 
GROUP BY 
    customer_name,
	city
Having COUNT(cust_id) > 1
)
  SELECT
		cd.* ,
        CASE WHEN fc.cust_id_count IS NOT NULL 
			THEN 'FRAUD' 
		ELSE 'NORMAL' 
        END AS fraud_flag
		
  FROM 
	cust_details AS cd
    LEFT JOIN 
    fraud_cust_list as fc
		ON cd.customer_name = fc.customer_name AND
			cd.city = fc.city;