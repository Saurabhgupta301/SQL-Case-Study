SELECT * FROM sakila ;


-- Graded Question II
-- (1) Busiest Actor
-- Write a query to find the full name of the actor who has acted in the maximum number of movies.
-- Sample Output
-- Full_name
-- PENELOPE GUINESS

SELECT concat(actor.first_name , ' '  , actor.last_name) AS Full_name
FROM actor 
INNER JOIN film_actor USING (actor_id)
group by (film_actor.actor_id)
ORDER BY count(film_actor.film_id) DESC
LIMIT 1; 

-- Another approach
select concat(a.first_name, ' ' , a.last_name ) as Full_name 
from actor a 
order by (select count(*) from film_actor fa where fa.actor_id = a.actor_id ) desc
limit 1;

-- (2) Third most Busy Actor
-- Write a query to find the full name of the actor who has acted in the third most number of movies.
-- Sample Output
-- Actor_name
-- PENELOPE GUINESS

select concat(first_name , ' ' , last_name) as Actor_name
from actor a
inner join film_actor using (actor_id)
group by (film_actor.actor_id)
order by count(film_actor.film_id) desc
limit 1 offset 2 ;

-- (3) Highest Grossing Film
-- Write a query to find the film which grossed the highest revenue for the video renting organisation.
-- Sample Output
-- title
-- ACADEMY DINOSAUR

SELECT title 
FROM film 
INNER JOIN inventory USING (film_id)
INNER JOIN rental USING (inventory_id)
INNER JOIN payment USING (rental_id)
GROUP BY title 
ORDER BY sum(amount) DESC
LIMIT 1 ;
 
  -- Graded Question III 
-- (1) Film-obsessed City
-- Write a query to find the city which generated the maximum revenue for the organisation.
-- Sample Output
-- city
-- Abu Dhabi

SELECT city 
FROM  city 
INNER JOIN address USING (city_id)
INNER JOIN customer USING (address_id)
INNER JOIN payment USING (customer_id)
GROUP BY city 
ORDER BY sum(amount) DESC 
LIMIT 1 ;

-- Graded Question IV
-- (1) Analysis of Movie Categories
-- Write a query to find out how many times a particular movie category is rented. Arrange these categories in the decreasing order of
-- the number of times they are rented.
-- Sample Output
-- Name   |  Rental_count   
-- Comedy |  15

SELECT name AS Name , count(rental_id) AS Rental_count
FROM category
INNER JOIN film_category USING (category_id)
INNER JOIN film USING (film_id)
INNER JOIN inventory USING (film_id)
INNER JOIN rental USING (inventory_id)
GROUP BY category_id , Name 
ORDER BY Rental_count DESC ; 

-- (2) Science Fiction Enthusiasts
-- Write a query to find the full names of customers who have rented sci-fi movies more than 2 times. Arrange these names in the alphabetical order.
-- Sample Output
-- Customer_name
-- MARY SMITH

SELECT concat(first_name , ' ' , last_name) AS Customer_name
FROM customer
INNER JOIN rental USING (customer_id)
INNER JOIN inventory USING (inventory_id)
INNER JOIN film USING (film_id)
INNER JOIN film_category USING (film_id)
INNER JOIN category USING (category_id)
WHERE name IN ('Sci-Fi')
GROUP BY Customer_name
HAVING count(rental_id) > 2
ORDER BY Customer_name

-- Graded Questions V
-- (1) Movie Fans from Arlington
-- Write a query to find the full names of those customers who have rented at least one movie and belong to the city Arlington.
-- Sample Output
-- Customer_name
-- MARY SMITH

SELECT concat(first_name , ' ' , last_name) AS Customer_name
FROM rental
INNER JOIN customer USING (customer_id)
INNER JOIN address USING (address_id)
INNER JOIN city USING (city_id)
WHERE city = "Arlington"
GROUP BY Customer_name
HAVING count(rental_id) > 0

-- (2) Country-wise Analysis of Movies
-- Write a query to find the number of movies rented across each country. Display only those countries where at least one movie was rented.
-- Arrange these countries in the alphabetical order.
-- Sample Output
-- Country     |  Rental_count
-- Afghanistan |   15

SELECT country as Country , count(rental_id) as Rental_count
FROM rental 
INNER JOIN customer USING (customer_id)
INNER JOIN address USING (address_id)
INNER JOIN city USING (city_id)
INNER JOIN Country USING (country_id)
GROUP BY Country
ORDER BY Country








