USE sakila;

/* (1) Most Productive Month
Description
Write a query to find the month number (Eg: 4 corresponds to April) in which the most number of payments were made.*/ 

SELECT month(payment_date) AS Payment_month
			,count(payment_id) AS No_of_payments
from payment
GROUP BY Payment_month
ORDER BY No_of_payments DESC
LIMIT 1;

/* (2) Average Film Length by Category
Description
List the rounded average film lengths for each film category. Arrange the values in the decreasing order of the average film lengths.*/

SELECT ROUND(AVG(length)) AS  avg_length,
       c.name AS name
FROM film AS f
INNER JOIN film_category AS fc
USING (film_id)
INNER JOIN category AS c
USING (category_id)
GROUP BY name
ORDER BY avg_length DESC;

/* (3) Film Category vs. City
Description
Write a query to find the number of occurrences of each film_category in each city. Arrange them in the decreasing order of their category count.*/

SELECT name ,
       city ,
       COUNT(city) AS category_count
FROM category 
INNER JOIN film_category 
	USING (category_id)
INNER JOIN inventory
	USING (film_id)
INNER JOIN store 
	USING (store_id)
INNER JOIN address
	USING (address_id)
INNER JOIN city
	USING (city_id)
GROUP BY name , city
ORDER BY category_count DESC;

/* (4) Ad Campaign
Description
Suppose you are running an advertising campaign in Canada for which you need the film_ids and titles of all the films released in Canada.
 List the films in the alphabetical order of their titles.*/
 
SELECT film_id AS Film_id,
	   title AS Title 
FROM film 
INNER JOIN inventory
	USING (film_id)
INNER JOIN store 
	USING (store_id)
INNER JOIN address
	USING (address_id)
INNER JOIN city
	USING (city_id)
INNER JOIN country
	USING (country_id)
WHERE country = 'CANADA'
GROUP BY Film_id, Title
ORDER BY Title;

/* (5) Comedy Movies
Description
Write a query to list all the films existing in the 'Comedy' category and arrange them in the alphabetical order.*/

SELECT title 
FROM film 
INNER JOIN film_category
	USING (film_id)
INNER JOIN category
	USING (category_id) 
WHERE name = 'Comedy'
GROUP BY title
ORDER BY title;
 
 /* (6) Lucky Customers
Description
List the first and last names of all customers whose first names start with the letters 'A', 'J' or 'T' or last names end with the substring 'on'.
 Arrange them alphabetically in the order of their first names.*/
 
 SELECT first_name AS First_name,
	    last_name AS Last_name
FROM customer
WHERE first_name LIKE 'A%' OR 
      first_name LIKE 'J%' OR 
      first_name LIKE 'T%' OR
	  last_name LIKE '%on'
GROUP BY first_name
ORDER BY first_name;
 
 



